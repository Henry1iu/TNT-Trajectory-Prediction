	
1.Replace the file "map_api.py" in the Argoverse api source code folder with this new version.
	The path of the "map_api.py": /Path_To_Your_Argoverse_API_Folder/argoverse/argoverse/map_representation

2.Replace the file "centerline_utils.py"
	The path of the "map_api.py": /Path_To_Your_Argoverse_API_Folder/argoverse/argoverse/utils
